<?php
/**
 * Template for displaying lesson item section in single course.
 *
 * This template can be overridden by copying it to yourtheme/learnpress/single-course/section/item-lesson.php.
 *
 * @author   ThimPress
 * @package  Learnpress/Templates
 * @version  4.0.0
 */

defined( 'ABSPATH' ) || exit();

if ( ! isset( $item ) ) {
	return;
}

global $wpdb;

$query = $wpdb->prepare(
	"
	SELECT *
	FROM {$wpdb->prefix}learnpress_user_lesson_recommendations
	WHERE user_id = %d AND item_id = %d",
	get_current_user_id(),(int)$item->get_id()
);

$queryres = $wpdb->get_results($query);

?>

<span class="item-nameRE item-recommended<?php if (sizeof($queryres) == 0){echo ' item-optional';} ?>"><?php echo esc_html( $item->get_title( 'display' ) ); ?></span>