<?php

 /**
 * Plugin Name: LearnPress - Lesson Recommendations
 * Plugin URI: https://csicy.com
 * Description: Adding recommendations for LearnPress Lessons
 * Author: CSICY
 * Version: 4.1.1
 * Author URI: https://csicy.com
 * Tags: learnpress
 * Requires at least: 5.8
 * Tested up to: 6.1.1
 * Text Domain: learnpress-lesson-recommendation
 * Domain Path: /languages/
 * Require_LP_Version: 4.2.0
 *
 * @package learnpress-lesson-recommendation
 */

if(!defined('ABSPATH')) {
	die; // Die if accessed directly.
}

function learnpress_user_lesson_recommendations(){
	// create the custom table
	global $wpdb;
	
	$table_name = $wpdb->prefix . 'learnpress_user_lesson_recommendations';
	$charset_collate = $wpdb->get_charset_collate();
	
	$sql = "CREATE TABLE IF NOT EXISTS $table_name (
	user_lesson_id BIGINT(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
	user_id BIGINT(20) unsigned NOT NULL DEFAULT '0',
	lesson_id BIGINT(20) unsigned NOT NULL DEFAULT '0',
	optional BOOLEAN DEFAULT FALSE) $charset_collate;";
	
	require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
	dbDelta( $sql );
}

//function returns true if an entry exist for the specific user_id, lesson_id combination
function entryExists($tablename, $lesson_id, $user_id){
    global $wpdb;
    
    $query = 'SELECT * FROM ' . $tablename . ' WHERE lesson_id = ' . $lesson_id . ' AND user_id = ' . $user_id;
    $result = $wpdb -> get_results($query);

    if(!is_null($result)){
        if (count($result)>0)   
            return true;
        else
            return false;
    }else
        return false;
}

register_activation_hook( __FILE__, 'learnpress_user_lesson_recommendations' );

add_action('rest_api_init', function () {
  register_rest_route( 'learnpress-recommended-lessons/v1', 'add-optional-lesson/(?P<user_id>\d+)/(?P<lesson_id>\d+)/(?P<optional>\d+)',array(
                'methods'  => 'GET',
                'callback' => 'add_learnpress_user_lesson_recommendation'
      ));
});

//function handles the api request for adding a single user lesson recommendation  
function add_learnpress_user_lesson_recommendation($request) {

    $response = new WP_REST_Response();
    
    global $wpdb;

    $tablename = $wpdb->prefix.'learnpress_user_lesson_recommendations';
    $lesson_id = $request['lesson_id'];
    $user_id = $request['user_id'];
    $optional = $request['optional'];
    
    $entryExists =  entryExists($tablename,$lesson_id,$user_id);
    
    $returnmessage = "Error";
    
    if($entryExists)
        try {
            $wpdb->update($tablename, array('$lesson_id'=>$lesson_id, '$user_id'=>$user_id), array('optional'=>$optional));
            
            $returnmessage = "Updated lesson " . $request['lesson_id'] . " for user " . $request['user_id'] . " to: " . $request['optional'];
        }
        //catch exception
        catch(Exception $e) {
          $returnmessage = "Error";
          $response->set_status(404);
        }
    else
        try {
            $data=array(
                'lesson_id' => $request['lesson_id'], 
                'user_id' => $request['user_id'],
                'optional' => $request['optional']);
    
            $result = $wpdb->insert( $tablename, $data);
        
            $returnmessage = "Added lesson " . $request['lesson_id'] . " for user " . $request['user_id'];
            $response->set_status(200);
        }
        //catch exception
        catch(Exception $e) {
          $returnmessage = "Error";
          $response->set_status(404);
        }
        
	return $returnmessage;
}

add_action('rest_api_init', function () {
  register_rest_route( 'learnpress-recommended-lessons/v1', 'add-multiple-optional-lessons/(?P<user_id>\d+)',array(
                'methods'  => 'POST',
                'callback' => 'add_multiple_learnpress_user_optional_lessons'
      ));
});

//function handles the api request for adding multiple user lesson recommendations
function add_multiple_learnpress_user_optional_lessons($request) {

    $response = new WP_REST_Response();
    global $wpdb;
    
    $user_id = $request['user_id'];
	
	$returnmessage = "";
	
	// Prepare the table name, taking into account the WordPress table prefix
	$tablename = $wpdb->prefix.'learnpress_user_lesson_recommendations';
	
	$updates = $request->get_json_params();

    // Prepare the SQL query to update the `optional` field for all user_id entries to 0
    $query = $wpdb->prepare(
        "UPDATE $tablename SET optional = 0 WHERE user_id = %d",
        $user_id
    );

    // Execute the query
    $result = $wpdb->query($query);

    // Check for query execution success
    if ($result === false) {
        // Query failed
        return false;
    }

    foreach ( $updates as $update ) {
        $lesson_id = $update['lessonId'];
        $optional = 0;
        
        if ($update['optional'] == "true")
            $optional = 1;
        
        $entryExists =  entryExists($tablename,$lesson_id,$user_id);
        
        if($entryExists)
            try {
                $wpdb->update($tablename, array('optional'=>$optional), array('lesson_id'=>$lesson_id, 'user_id'=>$user_id));
                
                $returnmessage = $returnmessage . "\nUser: " . $user_id . " Lesson: " . $lesson_id . " Optional: " . $optional . " (update)";
            }
            //catch exception
            catch(Exception $e) {
              $returnmessage = "\nError";
              $response->set_status(404);
            }
        else
            try {
                $data=array(
                    'lesson_id' => $lesson_id, 
                    'user_id' => $user_id,
                    'optional' => $optional);
        
                $result = $wpdb->insert( $tablename, $data);
            
                $returnmessage = $returnmessage . "\nUser: " . $user_id . " Lesson: " . $lesson_id . " Optional: " . $optional . " (insert)";
                $response->set_status(200);
            }
            //catch exception
            catch(Exception $e) {
              $returnmessage = "\nError";
              $response->set_status(404);
            }
    }

	return $returnmessage;
}

// Enqueue the custom CSS
function custom_course_item_title_css() {
    wp_enqueue_style( 'learnpress-recommended-lessons-style', plugin_dir_url( __FILE__ ) . 'learnpress_recommended_lessons_style.css' );
}
add_action( 'wp_enqueue_scripts', 'custom_course_item_title_css' );