<?php
/*
Plugin Name: Redirect Button with User Details
Description: Shortcode [redirectto_button pageurl="redirectionPath" target="_self/_blank/_parent/_top" text="ButtonText"] redirects to /pageurl?email=USER_EMAIL&fname=USER_FIRSTNAME&id=CURRENTUSER_ID
Version: 1.0
Author: CSICY
*/

// Create shortcode function
function redirect_button_user_details($atts) {
    // Extract shortcode attributes
    $atts = shortcode_atts(
        array(
            'pageurl' => '', // URL of the page to redirect to
            'text' => 'Click Here', // Text displayed on the button
            'target' => '_self' // Target attribute for link (_self, _blank, _parent, _top)
        ),
        $atts,
        'redirectto_button'
    );

    // Sanitize URL
    $pageurl = esc_url($atts['pageurl']);

    // Sanitize text
    $text = esc_html($atts['text']);

    // Sanitize target
    $target = in_array($atts['target'], array('_self', '_blank', '_parent', '_top')) ? $atts['target'] : '_self';
	
	// Set the target url to the selected page
	$tempurl = get_site_url() . '/' . $pageurl;
	
   if ( is_user_logged_in() ) {
	  	   
	$current_user = wp_get_current_user();

	// Append the user details to the target URL
	$tempurl .= '?email=' . urlencode($current_user->user_email) . '&fname='. $current_user->user_firstname . '&id='. $current_user->ID;
	  
   }

    // Generate button HTML
    $button_html = '<span class="csicy_redirectBtn"><a href="' . $tempurl . '" target="' . $target . '">' . $text . '</a></span>';

    // Return button HTML
    return $button_html;
}

// Register shortcode
add_shortcode('redirectto_button', 'redirect_button_user_details');
